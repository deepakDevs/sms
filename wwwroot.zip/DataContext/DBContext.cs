﻿using Microsoft.EntityFrameworkCore;
using SMS.Models;

namespace SMS.DataContext
{
    public class DBContext : DbContext
    {
        public DBContext(DbContextOptions<DBContext> options) : base(options) { }
        
        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Specify the dbo schema for the Students table
            modelBuilder.Entity<Student>().ToTable("Students", schema: "dbo");

            base.OnModelCreating(modelBuilder);
        }
    }
}
