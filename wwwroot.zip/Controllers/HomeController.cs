using Microsoft.AspNetCore.Mvc;
using SMS.DataContext;
using SMS.Models;
using System.Diagnostics;

namespace SMS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DBContext _dbContext;

        public HomeController(ILogger<HomeController> logger, DBContext dBContext)
        {
            _logger = logger;
            _dbContext = dBContext;
        }

        public IActionResult Index()
        {   

            @ViewBag.studentCount = _dbContext.Students.Count();
            @ViewBag.studentActiveCount = _dbContext.Students.Where(s => s.isActive == true).Count(); 
            @ViewBag.studentInactive = _dbContext.Students.Where(s=>s.isActive == false).Count();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
