﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SMS.DataContext;
using SMS.Models;

namespace SMS.Controllers
{
    public class StudentController : Controller
    {
        private readonly DBContext _dbContext;
        public StudentController(DBContext dbContext)
        {
            _dbContext = dbContext;
        }

        //static IList<Student> Students = new List<Student>
        //    {
        //        new Student { Id = 1, Name = "Alice", Age = 20, Phone="9568420035", Email="Alice@123.com ", Address="Uttar Pradesh"},
        //        new Student { Id = 2, Name = "Bob", Age = 22, Phone="9568420035", Email="Bob@123.com ", Address="Andhra Pradesh" },
        //        new Student {Id = 3, Name = "Charlie", Age = 23, Phone = "9568420035", Email = "Charlie@123.com ", Address = "Uttarakhand"}
        //    };
        public IActionResult Index()
        {
            return Content("Welcome to Student Controller Index Method.");
        }
             

        public async Task<IActionResult> Details()
        {        
            var Students = await _dbContext.Students.OrderBy(s=>s.Name).ToListAsync();
            TempData["studentCount"] = Students.Count();
            return  View(Students);
        }


        public IActionResult Add(Student std)
        {            
                return View();         
        }

        [HttpPost]
        public async Task<IActionResult> Create(Student newStudent)
        {
            if (ModelState.IsValid)
            {
                // Add the new student to the database context
                await _dbContext.Students.AddAsync(newStudent);

                // Save the changes to the database
                await _dbContext.SaveChangesAsync();

                // Redirect to the Details action to see the list of students
                return RedirectToAction("Details");
            }

            // If model state is invalid, return the view with the current data
            return View(newStudent);
        }



        public async Task<IActionResult> Edit(int id)
        {
            // Fetch the student record from the database by ID
            var student = await _dbContext.Students.FindAsync(id);

            // If student is not found, return NotFound
            if (student == null)
            {
                return NotFound();
            }

            // Pass the student data to the Edit view
            return View(student);
        }


        [HttpPost]
        public async Task<IActionResult> Edi(Student stud)
        {
            // Find the existing student record in the database
            var std = await _dbContext.Students.FindAsync(stud.Id);

            if (std != null)
            {
                // Update fields with new values
                std.Name = stud.Name;
                std.Age = stud.Age;
                std.Phone = stud.Phone;
                std.Email = stud.Email;
                std.Address = stud.Address;

                // Save changes to the database
                await _dbContext.SaveChangesAsync();

                // Redirect to Details view to see the updated list
                return RedirectToAction("Details");
            }

            // If student is not found, you may choose to return NotFound or Details page
            return RedirectToAction("Details");
        }


        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            // Find the student record in the database using the provided ID
            var student = await _dbContext.Students.FindAsync(id);

            if (student != null)
            {
                // Remove the student from the database
                _dbContext.Students.Remove(student);

                // Save changes to the database
                await _dbContext.SaveChangesAsync();

                // Redirect to the Details page to see the updated list of students
                return RedirectToAction("Details");
            }

            // If student not found, you can return a NotFound view or simply redirect to the Details page
            return RedirectToAction("Details");
        }
    }
}
